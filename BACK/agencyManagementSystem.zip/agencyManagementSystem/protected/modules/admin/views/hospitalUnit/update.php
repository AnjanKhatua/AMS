<?php
/* @var $this HospitalUnitController */
/* @var $model HospitalUnit */

$this->breadcrumbs=array(
	'Hospital Units'=>array('index'),
	$model->hospital_unit_id=>array('view','id'=>$model->hospital_unit_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List HospitalUnit', 'url'=>array('index')),
	array('label'=>'Create HospitalUnit', 'url'=>array('create')),
	array('label'=>'View HospitalUnit', 'url'=>array('view', 'id'=>$model->hospital_unit_id)),
	array('label'=>'Manage HospitalUnit', 'url'=>array('admin')),
);
?>

<h1>Update HospitalUnit <?php echo $model->hospital_unit_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>