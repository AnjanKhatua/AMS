<?php
/* @var $this HospitalUnitController */
/* @var $model HospitalUnit */

$this->breadcrumbs=array(
	'Hospital Units'=>array('index'),
	$model->hospital_unit_id,
);

$this->menu=array(
	array('label'=>'List HospitalUnit', 'url'=>array('index')),
	array('label'=>'Create HospitalUnit', 'url'=>array('create')),
	array('label'=>'Update HospitalUnit', 'url'=>array('update', 'id'=>$model->hospital_unit_id)),
	array('label'=>'Delete HospitalUnit', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->hospital_unit_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage HospitalUnit', 'url'=>array('admin')),
);
?>

<h1>View HospitalUnit #<?php echo $model->hospital_unit_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'hospital_unit_id',
		array(
                                            'name'=>'hospital_name',
                                            'value'=>$model->hospital->hospital_name,
                                        ),
		'hospital_unit',
		'address',
		array(
                                            'name'=>'area_name',
                                            'value'=>$model->localArea->area_name,
                                        ),
		'email',
		'contact_number',
		'hospital_unit_active_status',
	),
)); ?>
