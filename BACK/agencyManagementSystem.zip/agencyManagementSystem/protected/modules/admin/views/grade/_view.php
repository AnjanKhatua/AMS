<?php
/* @var $this GradeController */
/* @var $data Grade */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('grade_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->grade_id), array('view', 'id'=>$data->grade_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('grade_name')); ?>:</b>
	<?php echo CHtml::encode($data->grade_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('grade_active_status')); ?>:</b>
	<?php echo CHtml::encode($data->grade_active_status); ?>
	<br />


</div>