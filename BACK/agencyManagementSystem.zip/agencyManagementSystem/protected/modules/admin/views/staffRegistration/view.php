<?php
/* @var $this StaffRegistrationController */
/* @var $model StaffRegistration */

$this->breadcrumbs=array(
	'Staff Registrations'=>array('index'),
	$model->staff_id,
);

$this->menu=array(
	array('label'=>'List StaffRegistration', 'url'=>array('index')),
	array('label'=>'Create StaffRegistration', 'url'=>array('create')),
	array('label'=>'Update StaffRegistration', 'url'=>array('update', 'id'=>$model->staff_id)),
	array('label'=>'Delete StaffRegistration', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->staff_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage StaffRegistration', 'url'=>array('admin')),
);
?>

<h1>View StaffRegistration #<?php echo $model->staff_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'staff_id',
		'start_date',
		'first_name',
		'last_name',
		'gender',
		'date_of_birth',
		'ni_no',
		'nationality',
		'passport_no',
		'passport_issue_date',
		'passport_expiry_date',
		'visa_type',
		'visa_no',
		'visa_issue_date',
		'visa_expiry_date',
		'pay_type_id',
		'company_name',
		'company_no',
		'date_of_incorporation',
		'bank_details',
		'sort_code',
		'account_no',
		'email',
		'mobile_no',
		'telephone',
		'address',
		'post_code',
		'country',
		'job_type_id',
		'dbs_number',
		'dbs_issue_date',
		'dbs_expiry',
		'mandatory_training_expiry_date',
		'mva_expiry_date',
		'maybo_training_expiry',
		'pin_expiry_date',
		'max_allowed_hour',
		'image',
		'shift_confirmation_count',
		'shift_cancellation_count',
		'staff_status',
	),
)); ?>
