<?php
/* @var $this StaffRegistrationController */
/* @var $model StaffRegistration */

$this->breadcrumbs=array(
	'Staff Registrations'=>array('index'),
	$model->staff_id=>array('view','id'=>$model->staff_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List StaffRegistration', 'url'=>array('index')),
	array('label'=>'Create StaffRegistration', 'url'=>array('create')),
	array('label'=>'View StaffRegistration', 'url'=>array('view', 'id'=>$model->staff_id)),
	array('label'=>'Manage StaffRegistration', 'url'=>array('admin')),
);
?>

<h1>Update StaffRegistration <?php echo $model->staff_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>