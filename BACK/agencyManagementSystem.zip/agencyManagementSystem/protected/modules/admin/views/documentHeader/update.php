<?php
/* @var $this DocumentHeaderController */
/* @var $model DocumentHeader */

$this->breadcrumbs=array(
	'Document Headers'=>array('index'),
	$model->document_header_id=>array('view','id'=>$model->document_header_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List DocumentHeader', 'url'=>array('index')),
	array('label'=>'Create DocumentHeader', 'url'=>array('create')),
	array('label'=>'View DocumentHeader', 'url'=>array('view', 'id'=>$model->document_header_id)),
	array('label'=>'Manage DocumentHeader', 'url'=>array('admin')),
);
?>

<h1>Update DocumentHeader <?php echo $model->document_header_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>