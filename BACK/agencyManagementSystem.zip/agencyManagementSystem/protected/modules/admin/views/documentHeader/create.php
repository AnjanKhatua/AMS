<?php
/* @var $this DocumentHeaderController */
/* @var $model DocumentHeader */

$this->breadcrumbs=array(
	'Document Headers'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List DocumentHeader', 'url'=>array('index')),
	array('label'=>'Manage DocumentHeader', 'url'=>array('admin')),
);
?>

<h1>Create DocumentHeader</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>