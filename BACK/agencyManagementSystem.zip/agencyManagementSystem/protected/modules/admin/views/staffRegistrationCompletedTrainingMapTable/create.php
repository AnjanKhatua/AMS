<?php
/* @var $this StaffRegistrationCompletedTrainingMapTableController */
/* @var $model StaffRegistrationCompletedTrainingMapTable */

$this->breadcrumbs=array(
	'Staff Registration Completed Training Map Tables'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List StaffRegistrationCompletedTrainingMapTable', 'url'=>array('index')),
	array('label'=>'Manage StaffRegistrationCompletedTrainingMapTable', 'url'=>array('admin')),
);
?>

<h1>Create StaffRegistrationCompletedTrainingMapTable</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>