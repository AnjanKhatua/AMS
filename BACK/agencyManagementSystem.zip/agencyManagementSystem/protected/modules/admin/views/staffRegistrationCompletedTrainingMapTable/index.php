<?php
/* @var $this StaffRegistrationCompletedTrainingMapTableController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Staff Registration Completed Training Map Tables',
);

$this->menu=array(
	array('label'=>'Create StaffRegistrationCompletedTrainingMapTable', 'url'=>array('create')),
	array('label'=>'Manage StaffRegistrationCompletedTrainingMapTable', 'url'=>array('admin')),
);
?>

<h1>Staff Registration Completed Training Map Tables</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
