<?php
/* @var $this StaffRegistrationCompletedTrainingMapTableController */
/* @var $model StaffRegistrationCompletedTrainingMapTable */

$this->breadcrumbs=array(
	'Staff Registration Completed Training Map Tables'=>array('index'),
	$model->id,
);

$this->menu=array(
	array('label'=>'List StaffRegistrationCompletedTrainingMapTable', 'url'=>array('index')),
	array('label'=>'Create StaffRegistrationCompletedTrainingMapTable', 'url'=>array('create')),
	array('label'=>'Update StaffRegistrationCompletedTrainingMapTable', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete StaffRegistrationCompletedTrainingMapTable', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage StaffRegistrationCompletedTrainingMapTable', 'url'=>array('admin')),
);
?>

<h1>View StaffRegistrationCompletedTrainingMapTable #<?php echo $model->id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'id',
		'staff_id',
		'grade_id',
	),
)); ?>
