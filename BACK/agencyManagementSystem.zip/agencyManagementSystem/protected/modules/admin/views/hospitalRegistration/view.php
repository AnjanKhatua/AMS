<?php
/* @var $this HospitalRegistrationController */
/* @var $model HospitalRegistration */

$this->breadcrumbs=array(
	'Hospital Registrations'=>array('index'),
	$model->hospital_id,
);

$this->menu=array(
	array('label'=>'List HospitalRegistration', 'url'=>array('index')),
	array('label'=>'Create HospitalRegistration', 'url'=>array('create')),
	array('label'=>'Update HospitalRegistration', 'url'=>array('update', 'id'=>$model->hospital_id)),
	array('label'=>'Delete HospitalRegistration', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->hospital_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage HospitalRegistration', 'url'=>array('admin')),
);
?>

<h1>View HospitalRegistration #<?php echo $model->hospital_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'hospital_id',
		'hospital_name',
		'hospital_status',
	),
)); ?>
