<?php
/* @var $this HospitalRegistrationController */
/* @var $model HospitalRegistration */

$this->breadcrumbs=array(
	'Hospital Registrations'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List HospitalRegistration', 'url'=>array('index')),
	array('label'=>'Manage HospitalRegistration', 'url'=>array('admin')),
);
?>

<h1>Create HospitalRegistration</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>