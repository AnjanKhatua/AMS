<?php
/* @var $this ShiftManagementForHospitalController */
/* @var $model ShiftManagementForHospital */

$this->breadcrumbs=array(
	'Shift Management For Hospitals'=>array('index'),
	$model->staff_request_id,
);

$this->menu=array(
	array('label'=>'List ShiftManagementForHospital', 'url'=>array('index')),
	array('label'=>'Create ShiftManagementForHospital', 'url'=>array('create')),
	array('label'=>'Update ShiftManagementForHospital', 'url'=>array('update', 'id'=>$model->staff_request_id)),
	array('label'=>'Delete ShiftManagementForHospital', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->staff_request_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage ShiftManagementForHospital', 'url'=>array('admin')),
);
?>

<h1>View ShiftManagementForHospital #<?php echo $model->staff_request_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'staff_request_id',
		'hospital_unit_id',
		'job_type_id',
		'quantity',
		'date',
		'shift_start_time',
		'shift_end_time',
		'requested_date',
		'requested_time',
		'requested_person',
		'request_accepted_by',
		'requested_person_mobile_number',
	),
)); ?>
