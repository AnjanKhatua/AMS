<?php
/* @var $this ShiftManagementForHospitalController */
/* @var $model ShiftManagementForHospital */

$this->breadcrumbs=array(
	'Shift Management For Hospitals'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List ShiftManagementForHospital', 'url'=>array('index')),
	array('label'=>'Manage ShiftManagementForHospital', 'url'=>array('admin')),
);
?>

<h1>Create ShiftManagementForHospital</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>