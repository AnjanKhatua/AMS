<?php
/* @var $this ShiftManagementForHospitalController */
/* @var $model ShiftManagementForHospital */

$this->breadcrumbs=array(
	'Shift Management For Hospitals'=>array('index'),
	$model->staff_request_id=>array('view','id'=>$model->staff_request_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List ShiftManagementForHospital', 'url'=>array('index')),
	array('label'=>'Create ShiftManagementForHospital', 'url'=>array('create')),
	array('label'=>'View ShiftManagementForHospital', 'url'=>array('view', 'id'=>$model->staff_request_id)),
	array('label'=>'Manage ShiftManagementForHospital', 'url'=>array('admin')),
);
?>

<h1>Update ShiftManagementForHospital <?php echo $model->staff_request_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>