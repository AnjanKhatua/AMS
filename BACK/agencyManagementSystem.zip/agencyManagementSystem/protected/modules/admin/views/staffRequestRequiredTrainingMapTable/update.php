<?php
/* @var $this StaffRequestRequiredTrainingMapTableController */
/* @var $model StaffRequestRequiredTrainingMapTable */

$this->breadcrumbs=array(
	'Staff Request Required Training Map Tables'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List StaffRequestRequiredTrainingMapTable', 'url'=>array('index')),
	array('label'=>'Create StaffRequestRequiredTrainingMapTable', 'url'=>array('create')),
	array('label'=>'View StaffRequestRequiredTrainingMapTable', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage StaffRequestRequiredTrainingMapTable', 'url'=>array('admin')),
);
?>

<h1>Update StaffRequestRequiredTrainingMapTable <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>