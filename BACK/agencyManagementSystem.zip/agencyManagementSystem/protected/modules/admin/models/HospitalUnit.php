<?php

/**
 * This is the model class for table "{{hospital_unit}}".
 *
 * The followings are the available columns in table '{{hospital_unit}}':
 * @property string $hospital_unit_id
 * @property string $hospital_id
 * @property string $hospital_unit
 * @property string $address
 * @property string $local_area_id
 * @property string $email
 * @property string $contact_number
 * @property string $hospital_unit_active_status
 *
 * The followings are the available model relations:
 * @property WorkArea $localArea
 * @property HospitalRegistration $hospital
 * @property ServiceCompleted[] $serviceCompleteds
 * @property ShiftManagementForHospital[] $shiftManagementForHospitals
 */
class HospitalUnit extends CActiveRecord {

    public $hospital_name;
    public $area_name;
    /**
     * @return string the associated database table name
     */
    public function tableName() {
        return '{{hospital_unit}}';
    }

    /**
     * @return array validation rules for model attributes.
     */
    public function rules() {
        // NOTE: you should only define rules for those attributes that
        // will receive user inputs.
        return array(
//          array('hospital_id, hospital_unit, address, local_area_id, email, contact_number', 'required'),
            array('hospital_id, contact_number', 'length', 'max' => 10),
            array('hospital_unit', 'length', 'max' => 255),
            array('local_area_id', 'length', 'max' => 5),
            array('email', 'length', 'max' => 150),
            array('hospital_unit_active_status', 'length', 'max' => 1),
            array('hospital_name, area_name', 'length', 'min' => 0),
            // The following rule is used by search().
            // @todo Please remove those attributes that should not be searched.
            
            /*
             * @Function call for server side validation.
             */
            array('hospital_id', 'hospitalVarification'),
            array('hospital_unit', 'unitVarification'),
            array('address', 'addressVarification'),
            array('local_area_id', 'areaVarification'),
            array('email', 'emailVarification'),
            array('contact_number', 'contactVarification'),
            
            array('hospital_unit_id, hospital_id, hospital_unit, address, local_area_id, email, contact_number, hospital_unit_active_status', 'safe', 'on' => 'search'),
        );
    }

    /**
     * @return array relational rules.
     */
    public function relations() {
        // NOTE: you may need to adjust the relation name and the related
        // class name for the relations automatically generated below.
        return array(
            'localArea' => array(self::BELONGS_TO, 'WorkArea', 'local_area_id'),
            'hospital' => array(self::BELONGS_TO, 'HospitalRegistration', 'hospital_id'),
            'serviceCompleteds' => array(self::HAS_MANY, 'ServiceCompleted', 'hospital_unit_id'),
            'shiftManagementForHospitals' => array(self::HAS_MANY, 'ShiftManagementForHospital', 'hospital_unit_id'),
        );
    }

     /*
     * @Hospital selection validation for server side.
     */
    public function hospitalVarification($attribute, $params) {
        $hospital = $this->$attribute;
        $count = strlen($hospital);
        if ($count == 0) {
            $this->addError($attribute, 'Please choose any hospital!');
        } 
    }
    
    /*
     * @Hospital unit validation.
     */
    public function unitVarification($attribute, $params) {
        $hospitalUnitName = $this->$attribute;
        $countName = strlen($hospitalUnitName);
        $pattern = '/^([A-Z])+(([a-zA-Z0-9\s])+)+$/';
        if ($countName == 0) {
            $this->addError($attribute, 'Please enter hospital unit name!');
        } else if ($countName < 2) {
            $this->addError($attribute, 'Please enter valid unit name!');
        } else if (!preg_match($pattern, $hospitalUnitName)) {
            $this->addError($attribute, 'Please enter first character must be capital!');
        }
    }

    /*
     * @Hospital address validation.
     */
    public function addressVarification($attribute, $params) {
        $hospitalAddress = $this->$attribute;
        $count = strlen($hospitalAddress);
        if ($count == 0) {
            $this->addError($attribute, 'Please enter hospital address!');
        } 
    }
    
    /*
     * @Hospital local area selection.
     */
    public function areaVarification($attribute, $params) {
        $hospitalArea = $this->$attribute;
        $count = strlen($hospitalArea);
        if ($count == 0) {
            $this->addError($attribute, 'Please choose any hospital area!');
        } 
    }
    
    /*
     * @Email varification.
     */
    public function emailVarification($attribute, $params) {
        $email = $this->$attribute;
        $countEmail = strlen($email);
        $regex = '/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z]{2,4})+$/';
        if ($countEmail == 0) {
            $this->addError($attribute, 'Please enter email!');
        }else if (!preg_match($regex, $email)) {
            $this->addError($attribute, 'Please enter valid email!');
        }
    }
    
    /*
     * @Contact number varification.
     */
    public function contactVarification($attribute, $params) {
        $contactNumber = $this->$attribute;
        $countContactNumber = strlen($contactNumber);
        if ($countContactNumber == 0) {
            $this->addError($attribute, 'Please enter mobile number!');
        } else if (!preg_match('/^[1-9][0-9]{0,10}$/', $contactNumber)) {
            $this->addError($attribute, 'Please enter valid contact number!');
        } else if (strlen($contactNumber) != 10) {
            $this->addError($attribute, 'Please enter 10 digit mobile number!');
        }
    }
    
    /**
     * @return array customized attribute labels (name=>label)
     */
    public function attributeLabels() {
        return array(
            'hospital_unit_id' => 'Hospital Unit',
            'hospital_id' => 'hospital',
            'hospital_unit' => 'Hospital Unit',
            'address' => 'Address',
            'local_area_id' => 'localArea',
            'email' => 'Email',
            'contact_number' => 'Contact Number',
            'hospital_unit_active_status' => 'Hospital Unit Active Status',
        );
    }

    /**
     * Retrieves a list of models based on the current search/filter conditions.
     *
     * Typical usecase:
     * - Initialize the model fields with values from filter form.
     * - Execute this method to get CActiveDataProvider instance which will filter
     * models according to data in model fields.
     * - Pass data provider to CGridView, CListView or any similar widget.
     *
     * @return CActiveDataProvider the data provider that can return the models
     * based on the search/filter conditions.
     */
    public function search() {
        // @todo Please modify the following code to remove attributes that should not be searched.

        $criteria = new CDbCriteria;
        $criteria->with = array('hospital', 'localArea');
        $criteria->compare('hospital.hospital_name', $this->hospital_name, true);
        $criteria->compare('localArea.area_name', $this->area_name, true);
                                        
        $criteria->compare('hospital_unit_id', $this->hospital_unit_id, true);
        $criteria->compare('hospital_id', $this->hospital_id, true);
        $criteria->compare('hospital_unit', $this->hospital_unit, true);
        $criteria->compare('address', $this->address, true);
        $criteria->compare('local_area_id', $this->local_area_id, true);
        $criteria->compare('email', $this->email, true);
        $criteria->compare('contact_number', $this->contact_number, true);
        $criteria->compare('hospital_unit_active_status', $this->hospital_unit_active_status, true);

        return new CActiveDataProvider($this, array(
            'criteria' => $criteria,
        ));
    }

    /**
     * Returns the static model of the specified AR class.
     * Please note that you should have this exact method in all your CActiveRecord descendants!
     * @param string $className active record class name.
     * @return HospitalUnit the static model class
     */
    public static function model($className = __CLASS__) {
        return parent::model($className);
    }

}
