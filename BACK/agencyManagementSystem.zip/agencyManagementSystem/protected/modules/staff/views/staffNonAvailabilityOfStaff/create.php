<?php
/* @var $this StaffNonAvailabilityOfStaffController */
/* @var $model StaffNonAvailabilityOfStaff */

$this->breadcrumbs=array(
	'Staff Non Availability Of Staff'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List StaffNonAvailabilityOfStaff', 'url'=>array('index')),
	array('label'=>'Manage StaffNonAvailabilityOfStaff', 'url'=>array('admin')),
);
?>

<h1>Create StaffNonAvailabilityOfStaff</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>