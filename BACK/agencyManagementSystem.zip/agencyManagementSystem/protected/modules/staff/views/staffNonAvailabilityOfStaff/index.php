<?php
/* @var $this StaffNonAvailabilityOfStaffController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Staff Non Availability Of Staff',
);

$this->menu=array(
	array('label'=>'Create StaffNonAvailabilityOfStaff', 'url'=>array('create')),
	array('label'=>'Manage StaffNonAvailabilityOfStaff', 'url'=>array('admin')),
);
?>

<h1>Staff Non Availability Of Staff</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
