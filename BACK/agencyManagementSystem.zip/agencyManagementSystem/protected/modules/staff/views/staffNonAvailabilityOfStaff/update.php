<?php
/* @var $this StaffNonAvailabilityOfStaffController */
/* @var $model StaffNonAvailabilityOfStaff */

$this->breadcrumbs=array(
	'Staff Non Availability Of Staff'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List StaffNonAvailabilityOfStaff', 'url'=>array('index')),
	array('label'=>'Create StaffNonAvailabilityOfStaff', 'url'=>array('create')),
	array('label'=>'View StaffNonAvailabilityOfStaff', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage StaffNonAvailabilityOfStaff', 'url'=>array('admin')),
);
?>

<h1>Update StaffNonAvailabilityOfStaff <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>