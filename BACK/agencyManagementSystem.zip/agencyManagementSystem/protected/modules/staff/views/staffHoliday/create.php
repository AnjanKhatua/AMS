<?php
/* @var $this StaffHolidayController */
/* @var $model StaffHoliday */

$this->breadcrumbs=array(
	'Staff Holidays'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List StaffHoliday', 'url'=>array('index')),
	array('label'=>'Manage StaffHoliday', 'url'=>array('admin')),
);
?>

<h1>Create StaffHoliday</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>