<?php
/* @var $this StaffEnquiryController */
/* @var $model StaffEnquiry */

$this->breadcrumbs=array(
	'Staff Enquiries'=>array('index'),
	$model->enquiry_id=>array('view','id'=>$model->enquiry_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List StaffEnquiry', 'url'=>array('index')),
	array('label'=>'Create StaffEnquiry', 'url'=>array('create')),
	array('label'=>'View StaffEnquiry', 'url'=>array('view', 'id'=>$model->enquiry_id)),
	array('label'=>'Manage StaffEnquiry', 'url'=>array('admin')),
);
?>

<h1>Update StaffEnquiry <?php echo $model->enquiry_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>