<?php
/* @var $this StaffEnquiryController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Staff Enquiries',
);

$this->menu=array(
	array('label'=>'Create StaffEnquiry', 'url'=>array('create')),
	array('label'=>'Manage StaffEnquiry', 'url'=>array('admin')),
);
?>

<h1>Staff Enquiries</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
