<?php
/* @var $this StaffBookingController */
/* @var $model StaffBooking */

$this->breadcrumbs=array(
	'Staff Bookings'=>array('index'),
	$model->booking_id=>array('view','id'=>$model->booking_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List StaffBooking', 'url'=>array('index')),
	array('label'=>'Create StaffBooking', 'url'=>array('create')),
	array('label'=>'View StaffBooking', 'url'=>array('view', 'id'=>$model->booking_id)),
	array('label'=>'Manage StaffBooking', 'url'=>array('admin')),
);
?>

<h1>Update StaffBooking <?php echo $model->booking_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>