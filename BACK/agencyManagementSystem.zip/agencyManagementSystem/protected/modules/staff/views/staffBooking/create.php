<?php
/* @var $this StaffBookingController */
/* @var $model StaffBooking */

$this->breadcrumbs=array(
	'Staff Bookings'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List StaffBooking', 'url'=>array('index')),
	array('label'=>'Manage StaffBooking', 'url'=>array('admin')),
);
?>

<h1>Create StaffBooking</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>