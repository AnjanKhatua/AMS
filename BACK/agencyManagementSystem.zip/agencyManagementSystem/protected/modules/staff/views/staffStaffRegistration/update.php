<?php
/* @var $this StaffStaffRegistrationController */
/* @var $model StaffStaffRegistration */

$this->breadcrumbs=array(
	'Staff Staff Registrations'=>array('index'),
	$model->staff_id=>array('view','id'=>$model->staff_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List StaffStaffRegistration', 'url'=>array('index')),
	array('label'=>'Create StaffStaffRegistration', 'url'=>array('create')),
	array('label'=>'View StaffStaffRegistration', 'url'=>array('view', 'id'=>$model->staff_id)),
	array('label'=>'Manage StaffStaffRegistration', 'url'=>array('admin')),
);
?>

<h1>Update StaffStaffRegistration <?php echo $model->staff_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>