<?php
/* @var $this StaffStaffRegistrationController */
/* @var $model StaffStaffRegistration */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'staff-staff-registration-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'start_date'); ?>
		<?php echo $form->textField($model,'start_date'); ?>
		<?php echo $form->error($model,'start_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'first_name'); ?>
		<?php echo $form->textField($model,'first_name',array('size'=>60,'maxlength'=>75)); ?>
		<?php echo $form->error($model,'first_name'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'last_name'); ?>
		<?php echo $form->textField($model,'last_name',array('size'=>60,'maxlength'=>75)); ?>
		<?php echo $form->error($model,'last_name'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'gender'); ?>
		<?php echo $form->textField($model,'gender',array('size'=>6,'maxlength'=>6)); ?>
		<?php echo $form->error($model,'gender'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'date_of_birth'); ?>
		<?php echo $form->textField($model,'date_of_birth'); ?>
		<?php echo $form->error($model,'date_of_birth'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'ni_no'); ?>
		<?php echo $form->textField($model,'ni_no',array('size'=>9,'maxlength'=>9)); ?>
		<?php echo $form->error($model,'ni_no'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'nationality'); ?>
		<?php echo $form->textField($model,'nationality',array('size'=>60,'maxlength'=>150)); ?>
		<?php echo $form->error($model,'nationality'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'passport_no'); ?>
		<?php echo $form->textField($model,'passport_no',array('size'=>9,'maxlength'=>9)); ?>
		<?php echo $form->error($model,'passport_no'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'passport_issue_date'); ?>
		<?php echo $form->textField($model,'passport_issue_date'); ?>
		<?php echo $form->error($model,'passport_issue_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'passport_expiry_date'); ?>
		<?php echo $form->textField($model,'passport_expiry_date'); ?>
		<?php echo $form->error($model,'passport_expiry_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'visa_type'); ?>
		<?php echo $form->textField($model,'visa_type',array('size'=>60,'maxlength'=>100)); ?>
		<?php echo $form->error($model,'visa_type'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'visa_no'); ?>
		<?php echo $form->textField($model,'visa_no',array('size'=>16,'maxlength'=>16)); ?>
		<?php echo $form->error($model,'visa_no'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'visa_issue_date'); ?>
		<?php echo $form->textField($model,'visa_issue_date'); ?>
		<?php echo $form->error($model,'visa_issue_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'visa_expiry_date'); ?>
		<?php echo $form->textField($model,'visa_expiry_date'); ?>
		<?php echo $form->error($model,'visa_expiry_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'pay_type_id'); ?>
		<?php echo $form->textField($model,'pay_type_id',array('size'=>5,'maxlength'=>5)); ?>
		<?php echo $form->error($model,'pay_type_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'company_name'); ?>
		<?php echo $form->textArea($model,'company_name',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'company_name'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'company_no'); ?>
		<?php echo $form->textField($model,'company_no',array('size'=>11,'maxlength'=>11)); ?>
		<?php echo $form->error($model,'company_no'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'date_of_incorporation'); ?>
		<?php echo $form->textField($model,'date_of_incorporation'); ?>
		<?php echo $form->error($model,'date_of_incorporation'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'bank_details'); ?>
		<?php echo $form->textArea($model,'bank_details',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'bank_details'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'sort_code'); ?>
		<?php echo $form->textField($model,'sort_code',array('size'=>6,'maxlength'=>6)); ?>
		<?php echo $form->error($model,'sort_code'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'account_no'); ?>
		<?php echo $form->textField($model,'account_no',array('size'=>11,'maxlength'=>11)); ?>
		<?php echo $form->error($model,'account_no'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'email'); ?>
		<?php echo $form->textField($model,'email',array('size'=>60,'maxlength'=>150)); ?>
		<?php echo $form->error($model,'email'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'mobile_no'); ?>
		<?php echo $form->textField($model,'mobile_no',array('size'=>11,'maxlength'=>11)); ?>
		<?php echo $form->error($model,'mobile_no'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'telephone'); ?>
		<?php echo $form->textField($model,'telephone',array('size'=>11,'maxlength'=>11)); ?>
		<?php echo $form->error($model,'telephone'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'address'); ?>
		<?php echo $form->textArea($model,'address',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'address'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'post_code'); ?>
		<?php echo $form->textField($model,'post_code',array('size'=>8,'maxlength'=>8)); ?>
		<?php echo $form->error($model,'post_code'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'country'); ?>
		<?php echo $form->textField($model,'country',array('size'=>60,'maxlength'=>150)); ?>
		<?php echo $form->error($model,'country'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'job_type_id'); ?>
		<?php echo $form->textField($model,'job_type_id',array('size'=>5,'maxlength'=>5)); ?>
		<?php echo $form->error($model,'job_type_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'dbs_number'); ?>
		<?php echo $form->textField($model,'dbs_number',array('size'=>11,'maxlength'=>11)); ?>
		<?php echo $form->error($model,'dbs_number'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'dbs_issue_date'); ?>
		<?php echo $form->textField($model,'dbs_issue_date'); ?>
		<?php echo $form->error($model,'dbs_issue_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'dbs_expiry'); ?>
		<?php echo $form->textField($model,'dbs_expiry'); ?>
		<?php echo $form->error($model,'dbs_expiry'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'mandatory_training_expiry_date'); ?>
		<?php echo $form->textField($model,'mandatory_training_expiry_date'); ?>
		<?php echo $form->error($model,'mandatory_training_expiry_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'mva_expiry_date'); ?>
		<?php echo $form->textField($model,'mva_expiry_date'); ?>
		<?php echo $form->error($model,'mva_expiry_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'maybo_training_expiry'); ?>
		<?php echo $form->textField($model,'maybo_training_expiry'); ?>
		<?php echo $form->error($model,'maybo_training_expiry'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'pin_expiry_date'); ?>
		<?php echo $form->textField($model,'pin_expiry_date'); ?>
		<?php echo $form->error($model,'pin_expiry_date'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'max_allowed_hour'); ?>
		<?php echo $form->textField($model,'max_allowed_hour'); ?>
		<?php echo $form->error($model,'max_allowed_hour'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'image'); ?>
		<?php echo $form->textField($model,'image',array('size'=>60,'maxlength'=>255)); ?>
		<?php echo $form->error($model,'image'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'shift_confirmation_count'); ?>
		<?php echo $form->textField($model,'shift_confirmation_count',array('size'=>5,'maxlength'=>5)); ?>
		<?php echo $form->error($model,'shift_confirmation_count'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'shift_cancellation_count'); ?>
		<?php echo $form->textField($model,'shift_cancellation_count',array('size'=>5,'maxlength'=>5)); ?>
		<?php echo $form->error($model,'shift_cancellation_count'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'staff_status'); ?>
		<?php echo $form->textField($model,'staff_status',array('size'=>2,'maxlength'=>2)); ?>
		<?php echo $form->error($model,'staff_status'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->