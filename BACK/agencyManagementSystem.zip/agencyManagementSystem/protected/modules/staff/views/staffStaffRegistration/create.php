<?php
/* @var $this StaffStaffRegistrationController */
/* @var $model StaffStaffRegistration */

$this->breadcrumbs=array(
	'Staff Staff Registrations'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List StaffStaffRegistration', 'url'=>array('index')),
	array('label'=>'Manage StaffStaffRegistration', 'url'=>array('admin')),
);
?>

<h1>Create StaffStaffRegistration</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>