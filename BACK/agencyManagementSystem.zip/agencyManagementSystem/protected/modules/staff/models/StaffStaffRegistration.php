<?php

/**
 * This is the model class for table "{{staff_registration}}".
 *
 * The followings are the available columns in table '{{staff_registration}}':
 * @property string $staff_id
 * @property string $start_date
 * @property string $first_name
 * @property string $last_name
 * @property string $gender
 * @property string $date_of_birth
 * @property string $ni_no
 * @property string $nationality
 * @property string $passport_no
 * @property string $passport_issue_date
 * @property string $passport_expiry_date
 * @property string $visa_type
 * @property string $visa_no
 * @property string $visa_issue_date
 * @property string $visa_expiry_date
 * @property string $pay_type_id
 * @property string $company_name
 * @property string $company_no
 * @property string $date_of_incorporation
 * @property string $bank_details
 * @property string $sort_code
 * @property string $account_no
 * @property string $email
 * @property string $mobile_no
 * @property string $telephone
 * @property string $address
 * @property string $post_code
 * @property string $country
 * @property string $job_type_id
 * @property string $dbs_number
 * @property string $dbs_issue_date
 * @property string $dbs_expiry
 * @property string $mandatory_training_expiry_date
 * @property string $mva_expiry_date
 * @property string $maybo_training_expiry
 * @property string $pin_expiry_date
 * @property integer $max_allowed_hour
 * @property string $image
 * @property string $shift_confirmation_count
 * @property string $shift_cancellation_count
 * @property string $staff_status
 *
 * The followings are the available model relations:
 * @property Booking[] $bookings
 * @property Holiday[] $holidays
 * @property ServiceCompleted[] $serviceCompleteds
 * @property StaffDocument[] $staffDocuments
 * @property PayType $payType
 * @property JobType $jobType
 * @property StaffRegistrationCompletedTrainingMapTable[] $staffRegistrationCompletedTrainingMapTables
 * @property StaffRegistrationPreferredWorkAreaMapTable[] $staffRegistrationPreferredWorkAreaMapTables
 */
class StaffStaffRegistration extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{staff_registration}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('start_date, first_name, last_name, gender, date_of_birth, ni_no, nationality, passport_no, passport_issue_date, passport_expiry_date, visa_type, visa_no, visa_issue_date, visa_expiry_date, pay_type_id, company_name, company_no, date_of_incorporation, bank_details, sort_code, account_no, email, mobile_no, telephone, address, post_code, country, job_type_id, dbs_number, dbs_issue_date, dbs_expiry, mandatory_training_expiry_date, mva_expiry_date, maybo_training_expiry, pin_expiry_date, max_allowed_hour, image, shift_confirmation_count, shift_cancellation_count', 'required'),
			array('max_allowed_hour', 'numerical', 'integerOnly'=>true),
			array('first_name, last_name', 'length', 'max'=>75),
			array('gender, sort_code', 'length', 'max'=>6),
			array('ni_no, passport_no', 'length', 'max'=>9),
			array('nationality, email, country', 'length', 'max'=>150),
			array('visa_type', 'length', 'max'=>100),
			array('visa_no', 'length', 'max'=>16),
			array('pay_type_id, job_type_id, shift_confirmation_count, shift_cancellation_count', 'length', 'max'=>5),
			array('company_no, account_no, mobile_no, telephone, dbs_number', 'length', 'max'=>11),
			array('post_code', 'length', 'max'=>8),
			array('image', 'length', 'max'=>255),
			array('staff_status', 'length', 'max'=>2),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('staff_id, start_date, first_name, last_name, gender, date_of_birth, ni_no, nationality, passport_no, passport_issue_date, passport_expiry_date, visa_type, visa_no, visa_issue_date, visa_expiry_date, pay_type_id, company_name, company_no, date_of_incorporation, bank_details, sort_code, account_no, email, mobile_no, telephone, address, post_code, country, job_type_id, dbs_number, dbs_issue_date, dbs_expiry, mandatory_training_expiry_date, mva_expiry_date, maybo_training_expiry, pin_expiry_date, max_allowed_hour, image, shift_confirmation_count, shift_cancellation_count, staff_status', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'bookings' => array(self::HAS_MANY, 'Booking', 'staff_id'),
			'holidays' => array(self::HAS_MANY, 'Holiday', 'staff_id'),
			'serviceCompleteds' => array(self::HAS_MANY, 'ServiceCompleted', 'staff_id'),
			'staffDocuments' => array(self::HAS_MANY, 'StaffDocument', 'staff_id'),
			'payType' => array(self::BELONGS_TO, 'PayType', 'pay_type_id'),
			'jobType' => array(self::BELONGS_TO, 'JobType', 'job_type_id'),
			'staffRegistrationCompletedTrainingMapTables' => array(self::HAS_MANY, 'StaffRegistrationCompletedTrainingMapTable', 'staff_id'),
			'staffRegistrationPreferredWorkAreaMapTables' => array(self::HAS_MANY, 'StaffRegistrationPreferredWorkAreaMapTable', 'staff_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'staff_id' => 'Staff',
			'start_date' => 'Start Date',
			'first_name' => 'First Name',
			'last_name' => 'Last Name',
			'gender' => 'Gender',
			'date_of_birth' => 'Date Of Birth',
			'ni_no' => 'Ni No',
			'nationality' => 'Nationality',
			'passport_no' => 'Passport No',
			'passport_issue_date' => 'Passport Issue Date',
			'passport_expiry_date' => 'Passport Expiry Date',
			'visa_type' => 'Visa Type',
			'visa_no' => 'Visa No',
			'visa_issue_date' => 'Visa Issue Date',
			'visa_expiry_date' => 'Visa Expiry Date',
			'pay_type_id' => 'Pay Type',
			'company_name' => 'Company Name',
			'company_no' => 'Company No',
			'date_of_incorporation' => 'Date Of Incorporation',
			'bank_details' => 'Bank Details',
			'sort_code' => 'Sort Code',
			'account_no' => 'Account No',
			'email' => 'Email',
			'mobile_no' => 'Mobile No',
			'telephone' => 'Telephone',
			'address' => 'Address',
			'post_code' => 'Post Code',
			'country' => 'Country',
			'job_type_id' => 'Job Type',
			'dbs_number' => 'Dbs Number',
			'dbs_issue_date' => 'Dbs Issue Date',
			'dbs_expiry' => 'Dbs Expiry',
			'mandatory_training_expiry_date' => 'Mandatory Training Expiry Date',
			'mva_expiry_date' => 'Mva Expiry Date',
			'maybo_training_expiry' => 'Maybo Training Expiry',
			'pin_expiry_date' => 'Pin Expiry Date',
			'max_allowed_hour' => 'Max Allowed Hour',
			'image' => 'Image',
			'shift_confirmation_count' => 'Shift Confirmation Count',
			'shift_cancellation_count' => 'Shift Cancellation Count',
			'staff_status' => 'Staff Status',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('staff_id',$this->staff_id,true);
		$criteria->compare('start_date',$this->start_date,true);
		$criteria->compare('first_name',$this->first_name,true);
		$criteria->compare('last_name',$this->last_name,true);
		$criteria->compare('gender',$this->gender,true);
		$criteria->compare('date_of_birth',$this->date_of_birth,true);
		$criteria->compare('ni_no',$this->ni_no,true);
		$criteria->compare('nationality',$this->nationality,true);
		$criteria->compare('passport_no',$this->passport_no,true);
		$criteria->compare('passport_issue_date',$this->passport_issue_date,true);
		$criteria->compare('passport_expiry_date',$this->passport_expiry_date,true);
		$criteria->compare('visa_type',$this->visa_type,true);
		$criteria->compare('visa_no',$this->visa_no,true);
		$criteria->compare('visa_issue_date',$this->visa_issue_date,true);
		$criteria->compare('visa_expiry_date',$this->visa_expiry_date,true);
		$criteria->compare('pay_type_id',$this->pay_type_id,true);
		$criteria->compare('company_name',$this->company_name,true);
		$criteria->compare('company_no',$this->company_no,true);
		$criteria->compare('date_of_incorporation',$this->date_of_incorporation,true);
		$criteria->compare('bank_details',$this->bank_details,true);
		$criteria->compare('sort_code',$this->sort_code,true);
		$criteria->compare('account_no',$this->account_no,true);
		$criteria->compare('email',$this->email,true);
		$criteria->compare('mobile_no',$this->mobile_no,true);
		$criteria->compare('telephone',$this->telephone,true);
		$criteria->compare('address',$this->address,true);
		$criteria->compare('post_code',$this->post_code,true);
		$criteria->compare('country',$this->country,true);
		$criteria->compare('job_type_id',$this->job_type_id,true);
		$criteria->compare('dbs_number',$this->dbs_number,true);
		$criteria->compare('dbs_issue_date',$this->dbs_issue_date,true);
		$criteria->compare('dbs_expiry',$this->dbs_expiry,true);
		$criteria->compare('mandatory_training_expiry_date',$this->mandatory_training_expiry_date,true);
		$criteria->compare('mva_expiry_date',$this->mva_expiry_date,true);
		$criteria->compare('maybo_training_expiry',$this->maybo_training_expiry,true);
		$criteria->compare('pin_expiry_date',$this->pin_expiry_date,true);
		$criteria->compare('max_allowed_hour',$this->max_allowed_hour);
		$criteria->compare('image',$this->image,true);
		$criteria->compare('shift_confirmation_count',$this->shift_confirmation_count,true);
		$criteria->compare('shift_cancellation_count',$this->shift_cancellation_count,true);
		$criteria->compare('staff_status',$this->staff_status,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return StaffStaffRegistration the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
