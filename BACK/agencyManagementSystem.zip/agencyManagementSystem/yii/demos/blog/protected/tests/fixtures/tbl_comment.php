<?php

return array(
	/*
	'sample1'=>array(
		'content' => '',
		'status' => '',
		'create_time' => '',
		'author' => '',
		'email' => '',
		'url' => '',
		'post_id' => '',
	),
	'sample2'=>array(
		'content' => '',
		'status' => '',
		'create_time' => '',
		'author' => '',
		'email' => '',
		'url' => '',
		'post_id' => '',
	),
	*/
);
