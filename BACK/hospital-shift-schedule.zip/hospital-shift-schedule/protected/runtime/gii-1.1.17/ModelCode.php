<?php
return array (
  'template' => 'default',
  'connectionId' => 'db',
  'tablePrefix' => 'ams_',
  'modelPath' => 'application.modules.admin.models',
  'baseClass' => 'CActiveRecord',
  'buildRelations' => '1',
  'commentsAsLabels' => '0',
);
