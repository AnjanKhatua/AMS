<?php

/*
  Created on : 29th April, 2016
  It contains  frequently used functions
 */

class Utility {

    public static function validateAlphaWithSpaceField($ls_fieldValue) {
//        $la_message = array();
        if($ls_fieldValue=='')
            return 0;
        $ls_msg = 'Please enter only letters!';
        if (!preg_match("/^[\*a-zA-Z\s]{2,75}$/", $ls_fieldValue)) {
            return $ls_msg;
        } else {
            return 0;
        }
    }

    public static function validateEmailField($ls_fieldValue) {
//        $la_message = array();
        if($ls_fieldValue=='')
            return 0;
        $ls_msg = 'Please enter valid email!';
        if (!preg_match("/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z]{2,4})+$/", $ls_fieldValue)) {
            return $ls_msg;
        } else {
            return 0;
        }
    }

    public static function validateAlphaNumericField($ls_fieldValue) {
//        $la_message = array();
        if($ls_fieldValue=='')
            return 0;
        $ls_msg = 'Please enter only letters and numbers!';
        if (!preg_match("/^[a-zA-Z0-9]+$/", $ls_fieldValue)) {
            return $ls_msg;
        } else {
            return 0;
        }
    }

    public static function validateAlphaNumericWithSpaceAndSpecialField($ls_fieldValue) {
//        $la_message = array();
        if($ls_fieldValue=='')
            return 0;
        $ls_msg = 'Please enter only letters, numbers and special charecter!';
        if (!preg_match("/^[a-zA-Z0-9\s:,.@()-_]+$/", $ls_fieldValue)) {
            return $ls_msg;
        } else {
            return 0;
        }
    }

    public static function validateAlphaNumericWithSpaceField($ls_fieldValue) {
//        $la_message = array();
        if($ls_fieldValue=='')
            return 0;
        $ls_msg = 'Please enter only letters and numbers!';
        if (!preg_match("/^[a-zA-Z0-9\s]+$/", $ls_fieldValue)) {
            return $ls_msg;
        } else {
            return 0;
        }
    }

    public static function validateNumberField($ls_fieldValue) {
//        $la_message = array();
        if($ls_fieldValue=='')
            return 0;
        $ls_msg = 'Please enter only numbers!';
        if (!preg_match("/^\d+$/", $ls_fieldValue)) {
            return $ls_msg;
        } else {
            return 0;
        }
    }

    public static function changeDateToUK($ls_mysqlDate) {
        if($ls_mysqlDate=="0000-00-00") /* This is done for showing blank during date format conversion for 0000-00-00*/
        {
            return ''; 
        }
        return date("d-m-Y", strtotime($ls_mysqlDate));
    }

    public static function changeDateToMysql($ls_ukDate) {
        if (strpos($ls_ukDate, '/')) /* if the separator is a slash (/), then the American m/d/y is assumed. */ {
            $ls_ukDate = str_replace('/', '-', $ls_ukDate);
        }
        return date("Y-m-d", strtotime($ls_ukDate));
    }

}
?>