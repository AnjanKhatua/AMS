<?php
/* @var $this StaffRequestRequiredTrainingMapTableController */
/* @var $model StaffRequestRequiredTrainingMapTable */

$this->breadcrumbs=array(
	'Staff Request Required Training Map Tables'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List StaffRequestRequiredTrainingMapTable', 'url'=>array('index')),
	array('label'=>'Manage StaffRequestRequiredTrainingMapTable', 'url'=>array('admin')),
);
?>

<h1>Create StaffRequestRequiredTrainingMapTable</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>