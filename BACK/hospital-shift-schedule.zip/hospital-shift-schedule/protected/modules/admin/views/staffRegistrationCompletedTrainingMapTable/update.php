<?php
/* @var $this StaffRegistrationCompletedTrainingMapTableController */
/* @var $model StaffRegistrationCompletedTrainingMapTable */

$this->breadcrumbs=array(
	'Staff Registration Completed Training Map Tables'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List StaffRegistrationCompletedTrainingMapTable', 'url'=>array('index')),
	array('label'=>'Create StaffRegistrationCompletedTrainingMapTable', 'url'=>array('create')),
	array('label'=>'View StaffRegistrationCompletedTrainingMapTable', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage StaffRegistrationCompletedTrainingMapTable', 'url'=>array('admin')),
);
?>

<h1>Update StaffRegistrationCompletedTrainingMapTable <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>