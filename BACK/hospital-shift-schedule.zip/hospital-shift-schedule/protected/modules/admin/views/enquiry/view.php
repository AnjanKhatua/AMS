<?php
/* @var $this EnquiryController */
/* @var $model Enquiry */

$this->breadcrumbs=array(
	'Enquiries'=>array('index'),
	$model->enquiry_id,
);

$this->menu=array(
	array('label'=>'List Enquiry', 'url'=>array('index')),
	array('label'=>'Create Enquiry', 'url'=>array('create')),
	array('label'=>'Update Enquiry', 'url'=>array('update', 'id'=>$model->enquiry_id)),
	array('label'=>'Delete Enquiry', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->enquiry_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Enquiry', 'url'=>array('admin')),
);
?>

<h1>View Enquiry #<?php echo $model->enquiry_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'enquiry_id',
		'staff_request_id',
		'enquired_by',
		'availability_confirmed_by_staff',
		'availability_confirmed_via',
		'confirmed_by',
		'agent_user_id',
		'is_confirmed',
	),
)); ?>
