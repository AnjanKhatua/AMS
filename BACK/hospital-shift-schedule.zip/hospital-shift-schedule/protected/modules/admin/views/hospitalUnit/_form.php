<?php
/* @var $this HospitalUnitController */
/* @var $model HospitalUnit */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'hospital-unit-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>
                    <?php $selectedHospital=''; $selectedWorkPlace='';?>
	<?php echo $form->errorSummary($model); ?>

	<div class="row">
                                        <?php
                                        if(!$model->isNewRecord) {
                                            $selectedHospital = $model->hospital_id;
                                            }
                                        ?>
		<?php echo $form->labelEx($model,'hospital_id'); ?>
                                        <?php $allHospital = HospitalRegistration::model()->hospitalAll(); ?>                                        
                                        <?php echo CHtml::dropDownList('HospitalUnit[hospital_id]', $selectedHospital, $allHospital, array('single'=>'single'));?>
		<?php echo $form->error($model,'hospital_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'hospital_unit'); ?>
		<?php echo $form->textField($model,'hospital_unit',array('size'=>60,'maxlength'=>255)); ?>
		<?php echo $form->error($model,'hospital_unit'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'address'); ?>
		<?php echo $form->textArea($model,'address',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'address'); ?>
	</div>

	<div class="row">
                                        <?php
                                        if(!$model->isNewRecord) {
                                            $selectedWorkPlace = $model->local_area_id;
                                            }
                                        ?>
		<?php echo $form->labelEx($model,'local_area_id'); ?>
                                        <?php $allWorkPlace = WorkArea::model()->workPlaceAll(); ?>                                        
                                        <?php echo CHtml::dropDownList('HospitalUnit[local_area_id]', $selectedWorkPlace, $allWorkPlace, array('single'=>'single'));?>
		<?php echo $form->error($model,'local_area_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'email'); ?>
		<?php echo $form->emailField($model,'email',array('size'=>60,'maxlength'=>150)); ?>
		<?php echo $form->error($model,'email'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'contact_number'); ?>
		<?php echo $form->textField($model,'contact_number',array('size'=>10,'maxlength'=>10)); ?>
		<?php echo $form->error($model,'contact_number'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'hospital_unit_active_status'); ?>
		<?php echo $form->dropDownList($model,'hospital_unit_active_status',array("Y"=>"Yes", "N"=>"No")); ?>
		<?php echo $form->error($model,'hospital_unit_active_status'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->

<!--<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false&libraries=places"></script>
<script type="text/javascript">
google.maps.event.addDomListener(window, 'load', function () {
    var places = new google.maps.places.Autocomplete(document.getElementById('HospitalUnit_local_area_id'));
    google.maps.event.addListener(places, 'place_changed', function () {
        var place = places.getPlace();
        var address = place.formatted_address;
        var latitude = place.geometry.location.lat();
        var longitude = place.geometry.location.lng();
        var mesg = "Address: " + address;
        mesg += "\nLatitude: " + latitude;
        mesg += "\nLongitude: " + longitude;
        alert(mesg);
    });
});
    </script>-->