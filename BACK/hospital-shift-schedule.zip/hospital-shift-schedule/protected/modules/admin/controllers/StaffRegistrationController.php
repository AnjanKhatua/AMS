<?php

class StaffRegistrationController extends Controller {

    /**
     * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
     * using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout = '//layouts/column2';

    /**
     * @return array action filters
     */
    public function filters() {
        return array(
            'accessControl', // perform access control for CRUD operations
            'postOnly + delete', // we only allow deletion via POST request
        );
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     * @return array access control rules
     */
    public function accessRules() {
        return array(
            array('allow', // allow all users to perform 'index' and 'view' actions
                'actions' => array('index', 'view'),
                'users' => array('*'),
            ),
            array('allow', // allow authenticated user to perform 'create' and 'update' actions
                'actions' => array('create', 'update', 'admin', 'delete'),
                'users' => array('@'),
            ),
            array('allow', // allow admin user to perform 'admin' and 'delete' actions
                'actions' => array('admin', 'delete'),
                'users' => array('admin'),
            ),
            array('deny', // deny all users
                'users' => array('*'),
            ),
        );
    }

    /**
     * Displays a particular model.
     * @param integer $id the ID of the model to be displayed
     */
    public function actionView($id) {

        $lo_model = $this->loadModel($id);
        $lo_model->start_date = Utility::changeDateToUK($lo_model->start_date);
        $lo_model->date_of_birth = Utility::changeDateToUK($lo_model->date_of_birth);
        $lo_model->passport_issue_date = Utility::changeDateToUK($lo_model->passport_issue_date);
        $lo_model->passport_expiry_date = Utility::changeDateToUK($lo_model->passport_expiry_date);
        $lo_model->visa_issue_date = Utility::changeDateToUK($lo_model->visa_issue_date);
        $lo_model->visa_expiry_date = Utility::changeDateToUK($lo_model->visa_expiry_date);
        $lo_model->date_of_incorporation = Utility::changeDateToUK($lo_model->date_of_incorporation);
        $lo_model->dbs_issue_date = Utility::changeDateToUK($lo_model->dbs_issue_date);
        $lo_model->dbs_expiry = Utility::changeDateToUK($lo_model->dbs_expiry);
        $lo_model->mandatory_training_expiry_date = Utility::changeDateToUK($lo_model->mandatory_training_expiry_date);
        $lo_model->mva_expiry_date = Utility::changeDateToUK($lo_model->mva_expiry_date);
        $lo_model->maybo_training_expiry = Utility::changeDateToUK($lo_model->maybo_training_expiry);
        $lo_model->pin_expiry_date = Utility::changeDateToUK($lo_model->pin_expiry_date);
        $this->render('view', array(
            'model' => $lo_model,
        ));
    }

    /**
     * Creates a new model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     */
    public function actionCreate() {
        $model = new StaffRegistration;

        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);
        if (isset($_POST['StaffRegistration'])) {
            $model->attributes = $_POST['StaffRegistration'];
            if ($model->start_date != "") {
                $model->start_date = Utility::changeDateToMysql($model->start_date);
            }
            if ($model->date_of_birth != "") {
                $model->date_of_birth = Utility::changeDateToMysql($model->date_of_birth);
            }
            if ($model->passport_issue_date != "") {
                $model->passport_issue_date = Utility::changeDateToMysql($model->passport_issue_date);
            }
            if ($model->passport_expiry_date != "") {
                $model->passport_expiry_date = Utility::changeDateToMysql($model->passport_expiry_date);
            }
            if ($model->visa_issue_date != "") {
                $model->visa_issue_date = Utility::changeDateToMysql($model->visa_issue_date);
            }
            if ($model->visa_expiry_date != "") {
                $model->visa_expiry_date = Utility::changeDateToMysql($model->visa_expiry_date);
            }
            if ($model->date_of_incorporation != "") {
                $model->date_of_incorporation = Utility::changeDateToMysql($model->date_of_incorporation);
            }
            if ($model->dbs_issue_date != "") {
                $model->dbs_issue_date = Utility::changeDateToMysql($model->dbs_issue_date);
            }
            if ($model->dbs_expiry != "") {
                $model->dbs_expiry = Utility::changeDateToMysql($model->dbs_expiry);
            }
            if ($model->mandatory_training_expiry_date != "") {
                $model->mandatory_training_expiry_date = Utility::changeDateToMysql($model->mandatory_training_expiry_date);
            }
            if ($model->mva_expiry_date != "") {
                $model->mva_expiry_date = Utility::changeDateToMysql($model->mva_expiry_date);
            }
            if ($model->maybo_training_expiry != "") {
                $model->maybo_training_expiry = Utility::changeDateToMysql($model->maybo_training_expiry);
            }
            if ($model->pin_expiry_date != "") {
                $model->pin_expiry_date = Utility::changeDateToMysql($model->pin_expiry_date);
            }

            if ($model->staff_status != 'D')
                $model->scenario = 'exceptDraft';
            if ($model->save()) {
                if (isset($_POST['workAreaMap']['area'])) {
                    foreach ($_POST['workAreaMap']['area'] as $k => $lo_area) {
                        $modelWorkArea = new StaffRegistrationPreferredWorkAreaMapTable;
                        $modelWorkArea->staff_id = $model->staff_id;
                        $modelWorkArea->work_area_id = $lo_area;
//                        $la_workArea = Yii::app()->db->createCommand()
//                                ->select('staff_id, work_area_id')
//                                ->from('ams_staff_registration_preferred_work_area_map_table')
//                                ->where('staff_id=:staff_id and work_area_id=:work_area_id', array(':staff_id' => $model->staff_id, ':work_area_id' => $lo_area))
//                                ->queryRow();
//                        if (!$la_workArea)
                            $modelWorkArea->save();
                    }
                }

                $modelUser = new User;
                $modelUser->first_name = $model->first_name;
                $modelUser->last_name = $model->last_name;
                $modelUser->email = $model->email;
                $modelUser->password = md5($model->mobile_no);
                $modelUser->mobile = $model->mobile_no;
                $modelUser->address = $model->address;
                $modelUser->type = 'S';
                $modelUser->staff_id = $model->staff_id;
                if ($model->staff_status == 'D') {
                    $modelUser->active_status = 'N';
                } else {
                    $modelUser->active_status = 'Y';
                }
                $modelUser->save();

                $this->redirect(array('view', 'id' => $model->staff_id));
            }
        }

        $this->render('create', array(
            'model' => $model,
        ));
    }

    /**
     * Updates a particular model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id the ID of the model to be updated
     */
    public function actionUpdate($id) {
        $model = $this->loadModel($id);
        if ($model->start_date != "") {
            $model->start_date = Utility::changeDateToUK($model->start_date);
        }
        if ($model->date_of_birth != "") {
            $model->date_of_birth = Utility::changeDateToUK($model->date_of_birth);
        }
        if ($model->passport_issue_date != "") {
            $model->passport_issue_date = Utility::changeDateToUK($model->passport_issue_date);
        }
        if ($model->passport_expiry_date != "") {
            $model->passport_expiry_date = Utility::changeDateToUK($model->passport_expiry_date);
        }
        if ($model->visa_issue_date != "") {
            $model->visa_issue_date = Utility::changeDateToUK($model->visa_issue_date);
        }
        if ($model->visa_expiry_date != "") {
            $model->visa_expiry_date = Utility::changeDateToUK($model->visa_expiry_date);
        }
        if ($model->date_of_incorporation != "") {
            $model->date_of_incorporation = Utility::changeDateToUK($model->date_of_incorporation);
        }
        if ($model->dbs_issue_date != "") {
            $model->dbs_issue_date = Utility::changeDateToUK($model->dbs_issue_date);
        }
        if ($model->dbs_expiry != "") {
            $model->dbs_expiry = Utility::changeDateToUK($model->dbs_expiry);
        }
        if ($model->mandatory_training_expiry_date != "") {
            $model->mandatory_training_expiry_date = Utility::changeDateToUK($model->mandatory_training_expiry_date);
        }
        if ($model->mva_expiry_date != "") {
            $model->mva_expiry_date = Utility::changeDateToUK($model->mva_expiry_date);
        }
        if ($model->maybo_training_expiry != "") {
            $model->maybo_training_expiry = Utility::changeDateToUK($model->maybo_training_expiry);
        }
        if ($model->pin_expiry_date != "") {
            $model->pin_expiry_date = Utility::changeDateToUK($model->pin_expiry_date);
        }
        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);

        if (isset($_POST['StaffRegistration'])) {
            $model->attributes = $_POST['StaffRegistration'];
            if ($model->start_date != "") {
                $model->start_date = Utility::changeDateToMysql($model->start_date);
            }
            if ($model->date_of_birth != "") {
                $model->date_of_birth = Utility::changeDateToMysql($model->date_of_birth);
            }
            if ($model->passport_issue_date != "") {
                $model->passport_issue_date = Utility::changeDateToMysql($model->passport_issue_date);
            }
            if ($model->passport_expiry_date != "") {
                $model->passport_expiry_date = Utility::changeDateToMysql($model->passport_expiry_date);
            }
            if ($model->visa_issue_date != "") {
                $model->visa_issue_date = Utility::changeDateToMysql($model->visa_issue_date);
            }
            if ($model->visa_expiry_date != "") {
                $model->visa_expiry_date = Utility::changeDateToMysql($model->visa_expiry_date);
            }
            if ($model->date_of_incorporation != "") {
                $model->date_of_incorporation = Utility::changeDateToMysql($model->date_of_incorporation);
            }
            if ($model->dbs_issue_date != "") {
                $model->dbs_issue_date = Utility::changeDateToMysql($model->dbs_issue_date);
            }
            if ($model->dbs_expiry != "") {
                $model->dbs_expiry = Utility::changeDateToMysql($model->dbs_expiry);
            }
            if ($model->mandatory_training_expiry_date != "") {
                $model->mandatory_training_expiry_date = Utility::changeDateToMysql($model->mandatory_training_expiry_date);
            }
            if ($model->mva_expiry_date != "") {
                $model->mva_expiry_date = Utility::changeDateToMysql($model->mva_expiry_date);
            }
            if ($model->maybo_training_expiry != "") {
                $model->maybo_training_expiry = Utility::changeDateToMysql($model->maybo_training_expiry);
            }
            if ($model->pin_expiry_date != "") {
                $model->pin_expiry_date = Utility::changeDateToMysql($model->pin_expiry_date);
            }
            if ($model->staff_status != 'D')
                $model->scenario = 'exceptDraft';
            if ($model->save()) {
                if (isset($_POST['workAreaMap']['area'])) {
                    foreach ($_POST['workAreaMap']['area'] as $k => $lo_area) {
                        $modelWorkArea = new StaffRegistrationPreferredWorkAreaMapTable;
                        $modelWorkArea->staff_id = $model->staff_id;
                        $modelWorkArea->work_area_id = $lo_area;
                        $la_workArea = Yii::app()->db->createCommand()
                                ->select('staff_id, work_area_id')
                                ->from('ams_staff_registration_preferred_work_area_map_table')
                                ->where('staff_id=:staff_id and work_area_id=:work_area_id', array(':staff_id' => $model->staff_id, ':work_area_id' => $lo_area))
                                ->queryRow();
                        if (!$la_workArea)
                            $modelWorkArea->save();
                    }
                }

                $modelUser = new User;
                if ($model->staff_status == 'D') {
                    $modelUser->active_status = 'N';
                } else {
                    $modelUser->active_status = 'Y';
                }

                $data = array(
                    "first_name" => $model->first_name,
                    "last_name" => $model->last_name,
                    "email" => $model->email,
                    "password" => md5($model->mobile_no),
                    "mobile" => $model->mobile_no,
                    "address" => $model->address,
                    "type" => 'S',
                    "staff_id" => $model->staff_id,
                    "active_status" => $modelUser->active_status
                );
                $update = Yii::app()->db->createCommand()
                        ->update('ams_user', $data, 'staff_id=:staff_id', array(':id' => $model->staff_id)
                );


//                $modelUser->first_name = $model->first_name;
//                $modelUser->last_name = $model->last_name;
//                $modelUser->email = $model->email;
//                $modelUser->password = md5($model->mobile_no);
//                $modelUser->mobile = $model->mobile_no;
//                $modelUser->address = $model->address;
//                $modelUser->type = 'S';
//                $modelUser->staff_id = $model->staff_id;
//                
//                $modelUser->save();

                $this->redirect(array('view', 'id' => $model->staff_id));
            }
        }

        $this->render('update', array(
            'model' => $model,
        ));
    }

    /**
     * Deletes a particular model.
     * If deletion is successful, the browser will be redirected to the 'admin' page.
     * @param integer $id the ID of the model to be deleted
     */
    public function actionDelete($id) {
        $this->loadModel($id)->delete();

        // if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
        if (!isset($_GET['ajax']))
            $this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
    }

    /**
     * Lists all models.
     */
    public function actionIndex() {
        $dataProvider = new CActiveDataProvider('StaffRegistration');
        $this->render('index', array(
            'dataProvider' => $dataProvider,
        ));
    }

    /**
     * Manages all models.
     */
    public function actionAdmin() {
        $model = new StaffRegistration('search');
        $model->unsetAttributes();  // clear any default values
        if (isset($_GET['StaffRegistration']))
            $model->attributes = $_GET['StaffRegistration'];

        $this->render('admin', array(
            'model' => $model,
        ));
    }

//$lo_model =  $this->loadModel($id);
//        $lo_model->start_date = Utility::changeDateToUK($lo_model->start_date);
//        $this->render('view', array(
//            'model' =>$lo_model ,
//        ));
    /**
     * Returns the data model based on the primary key given in the GET variable.
     * If the data model is not found, an HTTP exception will be raised.
     * @param integer $id the ID of the model to be loaded
     * @return StaffRegistration the loaded model
     * @throws CHttpException
     */
    public function loadModel($id) {
        $model = StaffRegistration::model()->findByPk($id);
        if ($model === null)
            throw new CHttpException(404, 'The requested page does not exist.');
        return $model;
    }

    /**
     * Performs the AJAX validation.
     * @param StaffRegistration $model the model to be validated
     */
    protected function performAjaxValidation($model) {
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'staff-registration-form') {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }
    }

}
