<?php
/* @var $this StaffEnquiryController */
/* @var $model StaffEnquiry */

$this->breadcrumbs=array(
	'Staff Enquiries'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List StaffEnquiry', 'url'=>array('index')),
	array('label'=>'Manage StaffEnquiry', 'url'=>array('admin')),
);
?>

<h1>Create StaffEnquiry</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>