<?php
/* @var $this StaffBookingController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Staff Bookings',
);

$this->menu=array(
	array('label'=>'Create StaffBooking', 'url'=>array('create')),
	array('label'=>'Manage StaffBooking', 'url'=>array('admin')),
);
?>

<h1>Staff Bookings</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
