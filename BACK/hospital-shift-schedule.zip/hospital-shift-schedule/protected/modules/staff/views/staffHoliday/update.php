<?php
/* @var $this StaffHolidayController */
/* @var $model StaffHoliday */

$this->breadcrumbs=array(
	'Staff Holidays'=>array('index'),
	$model->holiday_id=>array('view','id'=>$model->holiday_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List StaffHoliday', 'url'=>array('index')),
	array('label'=>'Create StaffHoliday', 'url'=>array('create')),
	array('label'=>'View StaffHoliday', 'url'=>array('view', 'id'=>$model->holiday_id)),
	array('label'=>'Manage StaffHoliday', 'url'=>array('admin')),
);
?>

<h1>Update StaffHoliday <?php echo $model->holiday_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>