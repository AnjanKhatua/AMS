<?php
/* @var $this StaffNonAvailabilityOfStaffController */
/* @var $model StaffNonAvailabilityOfStaff */

$this->breadcrumbs=array(
	'Staff Non Availability Of Staff'=>array('index'),
	$model->id,
);

$this->menu=array(
	array('label'=>'List StaffNonAvailabilityOfStaff', 'url'=>array('index')),
	array('label'=>'Create StaffNonAvailabilityOfStaff', 'url'=>array('create')),
	array('label'=>'Update StaffNonAvailabilityOfStaff', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete StaffNonAvailabilityOfStaff', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage StaffNonAvailabilityOfStaff', 'url'=>array('admin')),
);
?>

<h1>View StaffNonAvailabilityOfStaff #<?php echo $model->id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'id',
		'staff_id',
		'date',
		'start_time',
		'end_time',
		'already_booked',
		'is_disabled',
	),
)); ?>
