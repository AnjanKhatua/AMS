<?php
/* @var $this StaffStaffRegistrationController */
/* @var $model StaffStaffRegistration */

$this->breadcrumbs=array(
	'Staff Staff Registrations'=>array('index'),
	$model->staff_id,
);

$this->menu=array(
	array('label'=>'List StaffStaffRegistration', 'url'=>array('index')),
	array('label'=>'Create StaffStaffRegistration', 'url'=>array('create')),
	array('label'=>'Update StaffStaffRegistration', 'url'=>array('update', 'id'=>$model->staff_id)),
	array('label'=>'Delete StaffStaffRegistration', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->staff_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage StaffStaffRegistration', 'url'=>array('admin')),
);
?>

<h1>View Staff Registration #<?php echo $model->staff_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'staff_id',
		'start_date',
		'first_name',
		'last_name',
		'gender',
		'date_of_birth',
		'ni_no',
		'nationality',
		'passport_no',
		'passport_issue_date',
		'passport_expiry_date',
		'visa_type',
		'visa_no',
		'visa_issue_date',
		'visa_expiry_date',
		'pay_type_id',
		'company_name',
		'company_no',
		'date_of_incorporation',
		'bank_details',
		'sort_code',
		'account_no',
		'email',
		'mobile_no',
		'telephone',
		'address',
		'post_code',
		'country',
		'job_type_id',
		'dbs_number',
		'dbs_issue_date',
		'dbs_expiry',
		'mandatory_training_expiry_date',
		'mva_expiry_date',
		'maybo_training_expiry',
		'pin_expiry_date',
		'max_allowed_hour',
		'image',
		'shift_confirmation_count',
		'shift_cancellation_count',
		'staff_status',
	),
)); ?>
