<?php
/* @var $this StaffStaffRegistrationController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Staff Staff Registrations',
);

$this->menu=array(
	array('label'=>'Create StaffStaffRegistration', 'url'=>array('create')),
	array('label'=>'Manage StaffStaffRegistration', 'url'=>array('admin')),
);
?>

<h1>Staff Registrations</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
